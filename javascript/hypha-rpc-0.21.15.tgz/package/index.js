module.exports = { hyphaWebsocketClient: require("./dist/hypha-rpc-websocket.js")};
